//#include <iostream>
//using namespace std;
//
//template <typename T>
//class List
//{
//protected:
//    T* array;
//    int currentsize;
//    int maxsize;
//
//public:
//    List(int max)
//    {
//        currentsize = 0;
//        maxsize = max;
//        array = new T[maxsize];
//    }
//
//    virtual ~List()
//    {
//        delete[] array;
//    }
//
//    virtual void arrayinsertion(T* arr2, int size2) = 0;
//    virtual void findsubarray(T* arr, int size) = 0;
//};
//
//template <typename T>
//class MYBST : public List<T>
//{
//public:
//    MYBST(T* arr, int max) : List<T>(max)
//    {
//        for (int i = 0; i < max; i++)
//        {
//            this->array[i] = arr[i];
//        }
//        this->currentsize = max;
//    }
//
//    void addelement(T element)
//    {
//        if (this->currentsize < this->maxsize)
//        {
//            this->array[this->currentsize] = element;
//            this->currentsize++;
//        }
//        else
//        {
//            cout << "Array is Full" << endl;
//        }
//    }
//
//    void arrayinsertion(T* arr2, int size2)
//    {
//        cout << "Common Elements: ";
//        for (int i = 0; i < this->currentsize; i++)
//        {
//            for (int j = 0; j < size2; j++)
//            {
//                if (this->array[i] == arr2[j])
//                {
//                    cout << this->array[i] << " ";
//                }
//            }
//        }
//        cout << endl;
//    }
//
//    void findsubarray(T* arr, int size)
//    {
//        int j = 0;
//        for (int i = 0; i < this->currentsize && j < size; i++)
//        {
//            if (this->array[i] == arr[j])
//            {
//                j++;
//            }
//        }
//        if (j == size)
//        {
//            cout << "The subarray is present in order." << endl;
//        }
//        else
//        {
//            cout << "The subarray is NOT present in order." << endl;
//        }
//    }
//
//    bool isprime(int num)
//    {
//        if (num < 2)
//        {
//            return false;
//        }
//        for (int i = 2; i * i <= num; i++)
//        {
//            if (num % i == 0)
//            {
//                return false;
//            }
//        }
//        return true;
//    }
//
//    void distinctprime()
//    {
//        int* temp = new int[this->currentsize]; 
//        int count1 = 0;
//
//        for (int i = 0; i < this->currentsize; i++)
//        {
//            if (this->isprime(this->array[i])) 
//            {
//                bool isdistinct = true;
//                for (int j = 0; j < count1; j++)
//                {
//                    if (temp[j] == this->array[i])
//                    {
//                        isdistinct = false;
//                        break;
//                    }
//                }
//                if (isdistinct)
//                {
//                    temp[count1++] = this->array[i];
//                }
//            }
//        }
//        cout << "Distinct Prime Numbers: ";
//        for (int i = 0; i < count1; i++)
//        {
//            cout << temp[i] << " ";
//        }
//        delete[] temp;
//    }
//
//    void primecount()
//    {
//        int count = 0;
//        for (int i = 0; i < this->currentsize; i++)
//        {
//            if (this->isprime(this->array[i])) 
//            {
//                count++;
//            }
//        }
//        cout << "Number of prime numbers in array: " << count << endl;
//    }
//
//    void display()
//    {
//        cout << "Array Elements: ";
//        for (int i = 0; i < this->currentsize; i++)
//        {
//            cout << this->array[i] << " ";
//        }
//        cout << endl;
//    }
//};
//
//int main()
//{
//    int array1[5] = { 1, 2, 3, 3, 5 };
//    int array2[4] = { 1, 6, 7, 5 };
//    int array3[3] = { 2, 3, 4 };
//
//    MYBST<int> m(array1, 5);
//
//    m.display();
//    m.arrayinsertion(array2, 4);
//    m.findsubarray(array3, 3);
//    m.primecount();
//    m.distinctprime();
//    return 0;
//}