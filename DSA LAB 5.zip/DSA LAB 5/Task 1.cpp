//#include<iostream>
//using namespace std;
//
//class Stack {
//protected:
//    char* arr;
//    int maxsize;
//    int top;
//public:
//    Stack(int size) {
//        maxsize = size;
//        arr = new char[size];
//        top = -1;
//    }
//
//    virtual void push(char value) = 0;
//    virtual char pop() = 0;
//};
//
//class Infix_converter : public Stack {
//public:
//    Infix_converter(int size) : Stack(size) {}
//
//    bool isFull() {
//        return top == maxsize - 1;
//    }
//
//    bool isEmpty() {
//        return top == -1;
//    }
//
//    void push(char value) {
//        if (!isFull()) {
//            arr[++top] = value;
//        }
//        else {
//            cout << "Stack is Full" << endl;
//        }
//    }
//
//    char pop() {
//        if (!isEmpty()) {
//            return arr[top--];
//        }
//        else {
//            cout << "Stack is Empty" << endl;
//            return '\0';
//        }
//    }
//
//    int size() {
//        return top + 1;
//    }
//
//    char getTop() {
//        if (!isEmpty()) {
//            return arr[top];
//        }
//        else {
//            cout << "Stack is Empty" << endl;
//            return '\0';
//        }
//    }
//
//    void display() {
//        if (isEmpty()) {
//            cout << "Stack is empty." << endl;
//        }
//        else {
//            for (int i = top; i >= 0; i--) {
//                cout << arr[i] << " ";
//            }
//            cout << endl;
//        }
//    }
//
//    int precedence(char c) {
//        if (c == '+' || c == '-') return 1;
//        else if (c == '*' || c == '/') return 2;
//        else return -1;
//    }
//
//    bool isOperator(char c) {
//        return c == '+' || c == '-' || c == '*' || c == '/';
//    }
//
//    string infix_to_postfix(string infix) {
//        string postfix = "";
//        for (int i = 0; i < infix.length(); i++) {
//            char c = infix[i];
//
//            if (isalnum(c)) {
//                postfix += c;
//            }
//            else if (c == '(') {
//                push(c);
//            }
//            else if (c == ')') {
//                while (!isEmpty() && getTop() != '(') {
//                    postfix += pop();
//                }
//                pop(); // remove '('
//            }
//            else if (isOperator(c)) {
//                while (!isEmpty() && precedence(getTop()) >= precedence(c)) {
//                    postfix += pop();
//                }
//                push(c);
//            }
//        }
//
//        while (!isEmpty()) {
//            postfix += pop();
//        }
//
//        return postfix;
//    }
//
//    string reverseString(string str) {
//        int start = 0;
//        int end = str.length() - 1;
//        while (start < end) {
//            char temp = str[start];
//            str[start] = str[end];
//            str[end] = temp;
//            start++;
//            end--;
//        }
//        return str;
//    }
//
//    void infix_to_prefix(string infix) {
//        // Step 1: Reverse the infix string manually
//        infix = reverseString(infix);
//
//        // Step 2: Swap brackets
//        for (int i = 0; i < infix.length(); i++) {
//            if (infix[i] == '(')
//                infix[i] = ')';
//            else if (infix[i] == ')')
//                infix[i] = '(';
//        }
//
//        // Step 3: Convert to postfix
//        string postfix = infix_to_postfix(infix);
//
//        // Step 4: Reverse postfix to get prefix
//        string prefix = reverseString(postfix);
//
//        cout << "Prefix Expression: " << prefix << endl;
//    }
//};
//
//int main() {
//    Infix_converter stack(50);
//    int choice;
//    char ch;
//    string expression;
//
//    do {
//        cout << "\n===== Stack Menu =====" << endl;
//        cout << "1. Push (Add new item to stack)" << endl;
//        cout << "2. Pop (Remove last element)" << endl;
//        cout << "3. Check if stack is full" << endl;
//        cout << "4. Check if stack is empty" << endl;
//        cout << "5. Stack size" << endl;
//        cout << "6. Get top element" << endl;
//        cout << "7. Infix to Postfix conversion" << endl;
//        cout << "8. Infix to Prefix conversion" << endl;
//        cout << "9. Display stack" << endl;
//        cout << "0. Exit" << endl;
//        cout << "Enter your choice: ";
//        cin >> choice;
//
//        switch (choice) {
//        case 1:
//            cout << "Enter character to push: ";
//            cin >> ch;
//            stack.push(ch);
//            break;
//        case 2:
//            ch = stack.pop();
//            if (ch != '\0') cout << "Popped: " << ch << endl;
//            break;
//        case 3:
//            if (stack.isFull()) cout << "Stack is full." << endl;
//            else cout << "Stack is not full." << endl;
//            break;
//        case 4:
//            if (stack.isEmpty()) cout << "Stack is empty." << endl;
//            else cout << "Stack is not empty." << endl;
//            break;
//        case 5:
//            cout << "Current size: " << stack.size() << endl;
//            break;
//        case 6:
//            ch = stack.getTop();
//            if (ch != '\0') cout << "Top element: " << ch << endl;
//            break;
//        case 7:
//            cout << "Enter infix expression: ";
//            cin >> expression;
//            cout << "Postfix: " << stack.infix_to_postfix(expression) << endl;
//            break;
//        case 8:
//            cout << "Enter infix expression: ";
//            cin >> expression;
//            stack.infix_to_prefix(expression);
//            break;
//        case 9:
//            cout << "Stack content: ";
//            stack.display();
//            break;
//        case 0:
//            cout << "Exiting program..." << endl;
//            break;
//        default:
//            cout << "Invalid choice!" << endl;
//        }
//
//    } while (choice != 0);
//
//    return 0;
//}
